package com.imdd.relics;

import com.imdd.relics.Relic.Eff;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.projectile.WindChargeEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntityEquipmentUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class RelicsMod implements ModInitializer {
    public static final String MOD_ID = "imdd_relics";

    /** IDs das entidades cuja armadura deve ficar escondida dos outros jogadores (usado pelo mixin). */
    public static final Set<Integer> HIDDEN_ARMOR = ConcurrentHashMap.newKeySet();

    private static final EquipmentSlot[] ARMOR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };
    private static final Random RNG = new Random();

    // ---- Relíquia do Explorador: magma que vai rachando ----
    private static final int MAGMA_DELAY_TICKS = 800;  // 40s sem rachar nada
    private static final int MAGMA_CRACK_TICKS = 600;  // depois disso: ~30s rachando devagar até quebrar (+ até 5s aleatórios)
    private static final List<MagmaTrack> MAGMA = new ArrayList<>();

    private static final class MagmaTrack {
        final ServerWorld world;
        final BlockPos pos;
        final int crack;
        int age = 0;
        int stage = -1;
        MagmaTrack(ServerWorld world, BlockPos pos) {
            this.world = world;
            this.pos = pos;
            this.crack = MAGMA_CRACK_TICKS + RNG.nextInt(100); // cada bloco racha no seu ritmo
        }
    }

    @Override
    public void onInitialize() {
        ModEffects.register();
        Relics.init();

        // ---------------- /relics (só abre o menu) ----------------
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("relics")
                        // .requires(src -> src.hasPermissionLevel(2))  // descomente pra só OP usar
                        .executes(ctx -> {
                            RelicMenu.open(ctx.getSource().getPlayerOrThrow());
                            return 1;
                        })));

        // ---------------- Habilidades ativas (clique direito) ----------------
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            Relic r = Relics.of(stack);
            if (r == null || !Relics.ACTIVE.contains(r.id())) return ActionResult.PASS;
            if (!world.isClient() && player instanceof ServerPlayerEntity sp) activate(sp, stack, r);
            return ActionResult.SUCCESS;
        });
        // Clique em bloco: impede o Ovo do Dragão de ser colocado, e usa a habilidade no lugar
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            ItemStack stack = player.getStackInHand(hand);
            Relic r = Relics.of(stack);
            if (r == null || !Relics.ACTIVE.contains(r.id())) return ActionResult.PASS;
            if (!world.isClient() && player instanceof ServerPlayerEntity sp) activate(sp, stack, r);
            return ActionResult.SUCCESS;
        });

        // ---------------- Dano: Stomper (queda) e Defesa (escudo) ----------------
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (!(entity instanceof PlayerEntity p)) return true;

            // Stomper: segurando em qualquer mão = imune a dano de queda
            if (source.isIn(DamageTypeTags.IS_FALL)
                    && (Relics.is(p.getMainHandStack(), "stomper") || Relics.is(p.getOffHandStack(), "stomper"))) {
                return false;
            }

            // Defesa: bloqueou com o escudo -> atacante leva 13,5 de dano + repulsão
            if (p.isBlocking() && p.getWorld() instanceof ServerWorld sw
                    && !source.isOf(DamageTypes.THORNS)
                    && Relics.is(p.getActiveItem(), "defesa")
                    && source.getAttacker() instanceof LivingEntity attacker
                    && source.getSource() == attacker
                    && blockedFromFront(p, source)) {
                attacker.damage(sw, sw.getDamageSources().thorns(p), 13.5f);
                attacker.takeKnockback(0.9, p.getX() - attacker.getX(), p.getZ() - attacker.getZ());
                attacker.velocityModified = true;
            }
            return true;
        });

        // ---------------- Imortalidade: salva da morte, 10s de recarga ----------------
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            if (!(entity instanceof ServerPlayerEntity p)) return true;
            if (source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) return true; // /kill, vazio

            PlayerInventory inv = p.getInventory();
            for (int i = 0; i < inv.size(); i++) {
                ItemStack st = inv.getStack(i);
                if (!Relics.is(st, "imortalidade")) continue;
                if (p.getItemCooldownManager().isCoolingDown(st)) return true; // em recarga: morre normal

                p.getItemCooldownManager().set(st, 200); // 10 segundos
                p.setHealth(1.0f);
                p.clearStatusEffects();
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 900, 1));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 100, 1));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 800, 0));
                playEnchantedTotem(p); // animação do totem, com brilho de encantado
                return false;
            }
            return true;
        });

        // ---------------- Tick: efeitos passivos, lava, armadura escondida ----------------
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int t = server.getTicks();
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (t % 10 == 0) applyPassiveEffects(p);
                if (t % 5 == 0) updateHiddenArmor(p);
                if (Relics.is(p.getEquippedStack(EquipmentSlot.FEET), "explorador")) lavaWalk(p);
            }
            tickMagma();
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) ->
                HIDDEN_ARMOR.remove(handler.getPlayer().getId()));
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) ->
                HIDDEN_ARMOR.remove(oldPlayer.getId()));
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            MAGMA.clear();
            HIDDEN_ARMOR.clear();
        });
    }

    // =====================================================================
    // Efeitos passivos
    // =====================================================================
    private static void applyPassiveEffects(ServerPlayerEntity p) {
        // Em qualquer lugar do inventário (Sorte)
        PlayerInventory inv = p.getInventory();
        Set<Relic> seen = new HashSet<>();
        for (int i = 0; i < inv.size(); i++) {
            Relic r = Relics.of(inv.getStack(i));
            if (r != null && r.where() == Relic.Where.INVENTORY && seen.add(r)) apply(p, r);
        }
        // Vestindo (armadura)
        for (EquipmentSlot slot : ARMOR) {
            Relic r = Relics.of(p.getEquippedStack(slot));
            if (r != null && r.where() == Relic.Where.WEAR) apply(p, r);
        }
    }

    private static void apply(PlayerEntity p, Relic r) {
        for (Eff e : r.effects()) {
            p.addStatusEffect(new StatusEffectInstance(e.effect(), e.duration(), e.amplifier(), true, false, true));
        }
    }

    // =====================================================================
    // Invisibilidade: esconde a armadura (do usuário) para os outros jogadores
    // =====================================================================
    private static void updateHiddenArmor(ServerPlayerEntity p) {
        boolean want = Relics.is(p.getEquippedStack(EquipmentSlot.FEET), "invisibilidade");
        boolean has = HIDDEN_ARMOR.contains(p.getId());
        if (want == has) return;
        if (want) HIDDEN_ARMOR.add(p.getId()); else HIDDEN_ARMOR.remove(p.getId());

        // Reenvia o equipamento aos outros jogadores (o mixin apaga as peças se estiver escondido)
        List<Pair<EquipmentSlot, ItemStack>> list = new ArrayList<>();
        for (EquipmentSlot slot : ARMOR) list.add(Pair.of(slot, p.getEquippedStack(slot).copy()));
        p.getServerWorld().getChunkManager().sendToOtherNearbyPlayers(p,
                new EntityEquipmentUpdateS2CPacket(p.getId(), list));
    }

    // =====================================================================
    // Explorador: lava 6x6 vira magma, que racha e quebra
    // =====================================================================
    private static void lavaWalk(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        BlockPos base = p.getBlockPos().down();
        for (int dx = -3; dx <= 2; dx++) {
            for (int dz = -3; dz <= 2; dz++) {
                BlockPos pos = base.add(dx, 0, dz);
                if (w.getBlockState(pos).isOf(Blocks.LAVA)
                        && w.getFluidState(pos).isStill()
                        && w.getBlockState(pos.up()).isAir()) {
                    w.setBlockState(pos, Blocks.MAGMA_BLOCK.getDefaultState());
                    MAGMA.add(new MagmaTrack(w, pos.toImmutable()));
                }
            }
        }
    }

    private static void tickMagma() {
        Iterator<MagmaTrack> it = MAGMA.iterator();
        while (it.hasNext()) {
            MagmaTrack t = it.next();
            t.age++;
            if (!t.world.getBlockState(t.pos).isOf(Blocks.MAGMA_BLOCK)) {
                it.remove();
                continue;
            }
            if (t.age < MAGMA_DELAY_TICKS) continue; // ainda não começou a rachar

            int elapsed = t.age - MAGMA_DELAY_TICKS;
            if (elapsed >= t.crack) {
                // Quebra SEM som: só partículas (o evento 2001 do jogo tocaria o som de quebrar bloco)
                t.world.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.MAGMA_BLOCK.getDefaultState()),
                        t.pos.getX() + 0.5, t.pos.getY() + 0.5, t.pos.getZ() + 0.5, 12, 0.25, 0.25, 0.25, 0.05);
                t.world.setBlockBreakingInfo(t.pos.hashCode(), t.pos, -1);
                t.world.setBlockState(t.pos, Blocks.LAVA.getDefaultState()); // quebra: a lava volta
                it.remove();
            } else {
                int stage = Math.min(9, elapsed * 10 / t.crack); // 10 estágios (rachadura laranja)
                if (stage != t.stage) {
                    t.stage = stage;
                    t.world.setBlockBreakingInfo(t.pos.hashCode(), t.pos, stage);
                }
            }
        }
    }

    /**
     * Animação do totem com brilho de encantamento. O cliente pega o item da animação da mão,
     * então mostramos um totem encantado na mão secundária só visualmente, disparamos a animação
     * e devolvemos o item real logo em seguida (tudo no mesmo tick; nada muda no servidor).
     */
    private static void playEnchantedTotem(ServerPlayerEntity p) {
        ItemStack fake = new ItemStack(Items.TOTEM_OF_UNDYING);
        fake.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        ItemStack real = p.getOffHandStack().copy();
        int syncId = p.playerScreenHandler.syncId;
        int revision = p.playerScreenHandler.getRevision();
        p.networkHandler.sendPacket(new ScreenHandlerSlotUpdateS2CPacket(syncId, revision, 45, fake));
        p.getServerWorld().sendEntityStatus(p, (byte) 35);
        p.networkHandler.sendPacket(new ScreenHandlerSlotUpdateS2CPacket(syncId, revision, 45, real));
    }

    // =====================================================================
    // Defesa
    // =====================================================================
    private static boolean blockedFromFront(PlayerEntity p, DamageSource source) {
        Vec3d pos = source.getPosition();
        if (pos == null) return false;
        Vec3d look = p.getRotationVec(1.0f);
        look = new Vec3d(look.x, 0, look.z);
        Vec3d toPlayer = pos.relativize(p.getPos());
        toPlayer = new Vec3d(toPlayer.x, 0, toPlayer.z).normalize();
        return toPlayer.dotProduct(look) < 0.0;
    }

    // =====================================================================
    // Habilidades ativas
    // =====================================================================
    private static void activate(ServerPlayerEntity p, ItemStack stack, Relic r) {
        var cd = p.getItemCooldownManager();
        if (cd.isCoolingDown(stack)) return;
        ServerWorld w = p.getServerWorld();

        switch (r.id()) {
            case "espiao" -> {
                // Efeito "Espião II" por 8 minutos: escala 0.1 (ver ModEffects). Recarga de 9 min.
                p.addStatusEffect(new StatusEffectInstance(ModEffects.ESPIAO, 8 * 60 * 20, 1, false, false, true));
                w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_ILLUSIONER_MIRROR_MOVE,
                        SoundCategory.PLAYERS, 1.0f, 1.0f);
                cd.set(stack, 9 * 60 * 20);
            }
            case "vento" -> {
                // Duas cargas lado a lado, mesma direção e sem dispersão: ficam coladas
                Vec3d fwd = p.getRotationVector();
                Vec3d side = fwd.crossProduct(new Vec3d(0, 1, 0));
                side = side.lengthSquared() < 1.0E-4 ? new Vec3d(1, 0, 0) : side.normalize();
                for (int i = 0; i < 2; i++) {
                    double off = i == 0 ? -0.12 : 0.12;
                    WindChargeEntity c = new WindChargeEntity(p, w,
                            p.getX() + side.x * off, p.getEyeY(), p.getZ() + side.z * off);
                    c.setVelocity(p, p.getPitch(), p.getYaw(), 0.0f, 1.5f, 0.0f);
                    w.spawnEntity(c);
                }
                w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_WIND_CHARGE_THROW,
                        SoundCategory.PLAYERS, 0.5f, 0.4f / (RNG.nextFloat() * 0.4f + 0.8f));
                cd.set(stack, 10); // carga infinita, só um respiro entre cliques
            }
            case "warden" -> {
                sonicBoom(p, w);
                cd.set(stack, 200); // 10 segundos
            }
            case "dragao" -> {
                randomTeleport(p, w);
                cd.set(stack, 20);
            }
            default -> { }
        }
    }

    /** Rajada sônica: 15 blocos, 5 de dano (ignora armadura, sem escala de dificuldade), joga ~10 blocos. */
    private static void sonicBoom(ServerPlayerEntity p, ServerWorld w) {
        Vec3d start = p.getEyePos();
        Vec3d dir = p.getRotationVector();
        Vec3d flat = new Vec3d(dir.x, 0, dir.z);
        Vec3d push = flat.lengthSquared() < 1.0E-4 ? Vec3d.ZERO : flat.normalize();

        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM,
                SoundCategory.PLAYERS, 3.0f, 1.0f);

        Set<LivingEntity> hit = new HashSet<>();
        for (int i = 1; i <= 15; i++) {
            Vec3d pos = start.add(dir.multiply(i));
            BlockPos bp = BlockPos.ofFloored(pos);
            if (!w.getBlockState(bp).getCollisionShape(w, bp).isEmpty()) break; // parede para a rajada
            if (i >= 2) { // partículas saem da mira e descem só um pouquinho
                double drop = 0.0025 * i * i;
                w.spawnParticles(ParticleTypes.SONIC_BOOM, pos.x, pos.y - drop, pos.z, 1, 0, 0, 0, 0);
            }
            Box box = new Box(pos, pos).expand(0.8);
            hit.addAll(w.getEntitiesByClass(LivingEntity.class, box, e -> e != p && e.isAlive()));
        }
        for (LivingEntity e : hit) {
            e.damage(w, w.getDamageSources().indirectMagic(p, p), 5.0f);
            e.setVelocity(push.x * 1.2, 0.4, push.z * 1.2); // ~10 blocos
            e.velocityModified = true;
        }
    }

    /** Teleporte aleatório estilo fruta do coro (até 16 blocos). */
    private static void randomTeleport(ServerPlayerEntity p, ServerWorld w) {
        Vec3d from = p.getPos();
        for (int i = 0; i < 16; i++) {
            double x = p.getX() + (RNG.nextDouble() - 0.5) * 32.0;
            double y = MathHelper.clamp(p.getY() + (RNG.nextInt(16) - 8),
                    w.getBottomY(), w.getBottomY() + w.getLogicalHeight() - 1);
            double z = p.getZ() + (RNG.nextDouble() - 0.5) * 32.0;
            if (p.hasVehicle()) p.stopRiding();
            if (p.teleport(x, y, z, true)) {
                w.spawnParticles(ParticleTypes.PORTAL, from.x, from.y + 1, from.z, 40, 0.4, 0.8, 0.4, 0.2);
                w.spawnParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 40, 0.4, 0.8, 0.4, 0.2);
                w.playSound(null, from.x, from.y, from.z, SoundEvents.ITEM_CHORUS_FRUIT_TELEPORT,
                        SoundCategory.PLAYERS, 1.0f, 1.0f);
                w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ITEM_CHORUS_FRUIT_TELEPORT,
                        SoundCategory.PLAYERS, 1.0f, 1.0f);
                return;
            }
        }
    }
}
