package com.imdd.relics;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/**
 * Magma criado pelas Botas do Explorador sobre a lava.
 *  - Fica 25s inteiro, depois ganha uma rachadura laranja a cada 5s (10 estágios) e quebra (a lava volta).
 *  - Quebra sem som.
 *  - Queima SEMPRE: agachado, com Resistência ao Fogo ou com bota comum. Só quem usa as Botas do Explorador é imune.
 * Os ticks agendados ficam salvos no mundo, então continua rachando depois de sair e entrar de novo.
 */
public class CrackingMagmaBlock extends Block {
    /** 0 = sem rachadura; 1..10 = estágios de rachadura. */
    public static final IntProperty CRACKS = IntProperty.of("cracks", 0, 10);

    public static final int DELAY_TICKS = 500; // 25s antes da 1ª rachadura
    public static final int STAGE_TICKS = 100; // +1 rachadura a cada 5s

    public CrackingMagmaBlock(Settings settings) {
        super(settings);
        this.setDefaultState(this.getStateManager().getDefaultState().with(CRACKS, 0));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(CRACKS);
    }

    @Override
    public void onSteppedOn(World world, BlockPos pos, BlockState state, Entity entity) {
        if (world instanceof ServerWorld sw
                && entity instanceof LivingEntity living
                && !Relics.is(living.getEquippedStack(EquipmentSlot.FEET), "explorador")) {
            // dano "genérico": não é de fogo, então Resistência ao Fogo não protege; agachar também não
            living.damage(sw, sw.getDamageSources().generic(), 1.0f);
        }
        super.onSteppedOn(world, pos, state, entity);
    }

    @Override
    protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        int cracks = state.get(CRACKS);
        if (cracks >= 10) {
            // Quebra SEM som: só partículas
            world.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.MAGMA_BLOCK.getDefaultState()),
                    pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 12, 0.25, 0.25, 0.25, 0.05);
            world.setBlockState(pos, Blocks.LAVA.getDefaultState()); // a lava volta
            return;
        }
        world.setBlockState(pos, state.with(CRACKS, cracks + 1), Block.NOTIFY_LISTENERS);
        world.scheduleBlockTick(pos, this, STAGE_TICKS);
    }
}
