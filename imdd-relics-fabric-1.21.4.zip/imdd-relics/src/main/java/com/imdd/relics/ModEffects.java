package com.imdd.relics;

import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

/**
 * Efeito "Espião" (ícone de olho). Aplicado com nível II (amplificador 1) deixa o jogador
 * com escala 0.1: 1.0 + (-0.45 * 2) = 0.1.
 */
public final class ModEffects {
    public static final double SCALE_PER_LEVEL = -0.45;

    public static RegistryEntry<StatusEffect> ESPIAO;

    private static final class EspiaoEffect extends StatusEffect {
        EspiaoEffect() {
            super(StatusEffectCategory.NEUTRAL, 0xFFFFFF);
            addAttributeModifier(EntityAttributes.SCALE,
                    Identifier.of(RelicsMod.MOD_ID, "effect.espiao"),
                    SCALE_PER_LEVEL,
                    EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        }
    }

    public static void register() {
        ESPIAO = Registry.registerReference(Registries.STATUS_EFFECT,
                Identifier.of(RelicsMod.MOD_ID, "espiao"), new EspiaoEffect());
    }

    private ModEffects() {}
}
