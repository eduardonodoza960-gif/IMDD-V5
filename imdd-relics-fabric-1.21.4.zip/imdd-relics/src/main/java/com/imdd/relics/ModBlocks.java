package com.imdd.relics;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

public final class ModBlocks {
    public static Block CRACKING_MAGMA;

    public static void register() {
        Identifier id = Identifier.of(RelicsMod.MOD_ID, "cracking_magma");
        RegistryKey<Block> key = RegistryKey.of(RegistryKeys.BLOCK, id);
        AbstractBlock.Settings settings = AbstractBlock.Settings.create()
                .registryKey(key)
                .mapColor(MapColor.DARK_RED)
                .strength(0.5f)
                .luminance(state -> 3)
                .dropsNothing();
        CRACKING_MAGMA = Registry.register(Registries.BLOCK, key, new CrackingMagmaBlock(settings));
    }

    private ModBlocks() {}
}
