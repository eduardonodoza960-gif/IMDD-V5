package com.imdd.relics;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.DyedColorComponent;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.component.type.UnbreakableComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Definição de uma relíquia (item base, nome, cor, encantamentos e efeitos passivos). */
public final class Relic {
    public record Ench(RegistryKey<Enchantment> key, int level) {}

    /** duration em ticks (20 = 1s). O efeito é renovado a cada 0,5s, então fica "infinito". */
    public record Eff(RegistryEntry<StatusEffect> effect, int amplifier, int duration) {}

    public enum Where { NONE, WEAR, INVENTORY }

    private final String id;
    private final Item item;
    private final String name;
    private final int color;
    private final List<Ench> enchants = new ArrayList<>();
    private final List<Eff> effects = new ArrayList<>();
    private final List<String> shownLines = new ArrayList<>();
    private boolean hideEnchants = false;
    private Where where = Where.NONE;
    private int dye = -1;

    private Relic(String id, Item item, String name, int color) {
        this.id = id;
        this.item = item;
        this.name = name;
        this.color = color;
    }

    public static Relic of(String id, Item item, String name, int color) {
        return new Relic(id, item, name, color);
    }

    public Relic ench(RegistryKey<Enchantment> key, int level) { enchants.add(new Ench(key, level)); return this; }
    public Relic hide() { hideEnchants = true; return this; }

    /** Esconde o encantamento real e mostra este texto no lugar dele (ex.: "Repulsão 50"). */
    public Relic shownAs(String line) { hideEnchants = true; shownLines.add(line); return this; }
    public Relic dye(int rgb) { dye = rgb; return this; }
    public Relic wear(Eff... e) { where = Where.WEAR; effects.addAll(List.of(e)); return this; }
    public Relic inventory(Eff... e) { where = Where.INVENTORY; effects.addAll(List.of(e)); return this; }

    public String id() { return id; }
    public String name() { return name; }
    public Where where() { return where; }
    public List<Eff> effects() { return effects; }

    public ItemStack createStack(DynamicRegistryManager registries) {
        ItemStack s = new ItemStack(item);

        // Nome: negrito + itálico + SUBLINHADO (pelo formatting padrão) + cor exata do print
        s.set(DataComponentTypes.CUSTOM_NAME, Text.literal(name)
                .formatted(Formatting.BOLD, Formatting.ITALIC, Formatting.UNDERLINE)
                .styled(st -> st.withColor(color)));

        if (!enchants.isEmpty()) {
            var registry = registries.getOrThrow(RegistryKeys.ENCHANTMENT);
            ItemEnchantmentsComponent.Builder b =
                    new ItemEnchantmentsComponent.Builder(ItemEnchantmentsComponent.DEFAULT);
            for (Ench e : enchants) {
                b.add(registry.getOrThrow(e.key()), e.level());
            }
            ItemEnchantmentsComponent c = b.build();
            if (hideEnchants) c = c.withShowInTooltip(false);
            s.set(DataComponentTypes.ENCHANTMENTS, c);
        }

        if (!shownLines.isEmpty()) {
            List<Text> lore = new ArrayList<>();
            for (String line : shownLines) {
                lore.add(Text.literal(line).setStyle(Style.EMPTY.withColor(0xAAAAAA).withItalic(false)));
            }
            s.set(DataComponentTypes.LORE, new LoreComponent(lore));
        }

        if (dye >= 0) s.set(DataComponentTypes.DYED_COLOR, new DyedColorComponent(dye, false));

        // Brilho de encantamento em TODAS as relíquias (mesmo as sem encantamento)
        s.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);

        // Inquebrável (sem aparecer no tooltip)
        s.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(false));

        // Relíquias não são comida e o totem é controlado pelo mod
        s.remove(DataComponentTypes.FOOD);
        s.remove(DataComponentTypes.CONSUMABLE);
        s.remove(DataComponentTypes.DEATH_PROTECTION);

        NbtCompound tag = new NbtCompound();
        tag.putString("relic_id", id);
        s.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(tag));
        return s;
    }
}
