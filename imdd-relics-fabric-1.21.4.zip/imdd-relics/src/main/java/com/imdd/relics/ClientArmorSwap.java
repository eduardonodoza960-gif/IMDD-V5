package com.imdd.relics;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Esvazia a armadura do jogador local só durante o desenho dele (elytra e abóbora ficam). */
public final class ClientArmorSwap {
    private static final ItemStack[] SAVED = new ItemStack[4];
    private static boolean active = false;

    private ClientArmorSwap() {}

    public static void hide(PlayerEntity player) {
        if (active) return;
        active = true;
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < 4; i++) {
            ItemStack st = inv.getStack(36 + i); // 36 botas, 37 calça, 38 peitoral, 39 capacete
            SAVED[i] = st;
            boolean keep = (i == 2 && st.isOf(Items.ELYTRA)) || (i == 3 && st.isOf(Items.CARVED_PUMPKIN));
            if (!keep) inv.setStack(36 + i, ItemStack.EMPTY);
        }
    }

    public static void restore(PlayerEntity player) {
        if (!active) return;
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < 4; i++) inv.setStack(36 + i, SAVED[i]);
        active = false;
    }
}
