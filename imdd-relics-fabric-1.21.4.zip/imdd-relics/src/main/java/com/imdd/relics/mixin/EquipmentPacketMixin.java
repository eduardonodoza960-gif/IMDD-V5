package com.imdd.relics.mixin;

import com.imdd.relics.RelicsMod;
import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntityEquipmentUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * Relíquia da Invisibilidade: quem usa a relíquia tem a armadura "apagada"
 * nos pacotes de equipamento enviados para os OUTROS jogadores.
 */
@Mixin(EntityEquipmentUpdateS2CPacket.class)
public abstract class EquipmentPacketMixin {

    @Inject(method = "<init>(ILjava/util/List;)V", at = @At("RETURN"), require = 0)
    private void imdd$hideArmor(int id, List<Pair<EquipmentSlot, ItemStack>> list, CallbackInfo ci) {
        if (!RelicsMod.HIDDEN_ARMOR.contains(id)) return;
        EntityEquipmentUpdateS2CPacket self = (EntityEquipmentUpdateS2CPacket) (Object) this;
        List<Pair<EquipmentSlot, ItemStack>> l = self.getEquipmentList();
        try {
            l.replaceAll(p -> {
                EquipmentSlot slot = p.getFirst();
                boolean armor = slot == EquipmentSlot.HEAD || slot == EquipmentSlot.CHEST
                        || slot == EquipmentSlot.LEGS || slot == EquipmentSlot.FEET;
                ItemStack st = p.getSecond();
                // esconde só armadura; elytra e abóbora esculpida continuam aparecendo; mãos não mudam
                if (!armor || st.isOf(Items.ELYTRA) || st.isOf(Items.CARVED_PUMPKIN)) return p;
                return Pair.of(slot, ItemStack.EMPTY);
            });
        } catch (UnsupportedOperationException ignored) {
        }
    }
}
