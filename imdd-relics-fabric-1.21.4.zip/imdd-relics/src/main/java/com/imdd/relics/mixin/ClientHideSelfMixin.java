package com.imdd.relics.mixin;

import com.imdd.relics.Relics;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Relíquia da Invisibilidade (lado do cliente): enquanto você estiver com a bota equipada,
 * seu corpo, armadura e a própria bota não são desenhados na 3ª pessoa (frente e costas).
 */
@Mixin(EntityRenderDispatcher.class)
public abstract class ClientHideSelfMixin {

    @Inject(method = "render(Lnet/minecraft/entity/Entity;DDDFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void imdd$hideSelf(Entity entity, double x, double y, double z, float tickDelta,
                               MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                               CallbackInfo ci) {
        if (entity == null || entity != MinecraftClient.getInstance().player) return;
        if (entity instanceof LivingEntity le
                && Relics.is(le.getEquippedStack(EquipmentSlot.FEET), "invisibilidade")) {
            ci.cancel();
        }
    }
}
