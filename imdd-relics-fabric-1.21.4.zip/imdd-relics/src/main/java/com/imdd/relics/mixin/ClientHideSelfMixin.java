package com.imdd.relics.mixin;

import com.imdd.relics.ClientArmorSwap;
import com.imdd.relics.Relics;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Relíquia da Invisibilidade (cliente): na SUA 3ª pessoa a armadura não é desenhada
 * (elytra e abóbora continuam; itens nas mãos continuam).
 */
@Mixin(EntityRenderDispatcher.class)
public abstract class ClientHideSelfMixin {
    private static final String RENDER =
            "render(Lnet/minecraft/entity/Entity;DDDFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V";

    @Inject(method = RENDER, at = @At("HEAD"), require = 0)
    private void imdd$hideArmor(Entity entity, double x, double y, double z, float tickDelta,
                                MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                CallbackInfo ci) {
        if (entity == null || entity != MinecraftClient.getInstance().player) return;
        if (entity instanceof PlayerEntity pe
                && Relics.is(pe.getEquippedStack(EquipmentSlot.FEET), "invisibilidade")) {
            ClientArmorSwap.hide(pe);
        }
    }

    @Inject(method = RENDER, at = @At("RETURN"), require = 0)
    private void imdd$restoreArmor(Entity entity, double x, double y, double z, float tickDelta,
                                   MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                   CallbackInfo ci) {
        if (entity instanceof PlayerEntity pe) ClientArmorSwap.restore(pe);
    }
}
