package com.imdd.relics;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.client.render.RenderLayer;

public class RelicsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // A rachadura laranja tem partes transparentes
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.CRACKING_MAGMA, RenderLayer.getCutout());
    }
}
