package com.imdd.relics;

import com.imdd.relics.Relic.Eff;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Lista de todas as relíquias, na MESMA ordem do menu do vídeo.
 * Cores (hex) tiradas dos prints.
 */
public final class Relics {
    public static final List<Relic> ALL = new ArrayList<>();
    private static final Map<String, Relic> BY_ID = new HashMap<>();

    /** Relíquias com habilidade ativa (clique direito). */
    public static final Set<String> ACTIVE = Set.of("espiao", "vento", "warden", "dragao");

    private Relics() {}

    private static void add(Relic r) {
        ALL.add(r);
        BY_ID.put(r.id(), r);
    }

    public static Relic of(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return null;
        NbtComponent data = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (data == null) return null;
        return BY_ID.get(data.copyNbt().getString("relic_id"));
    }

    public static boolean is(ItemStack stack, String id) {
        Relic r = of(stack);
        return r != null && r.id().equals(id);
    }

    public static void init() {
        // ===================== LINHA 1 =====================
        add(Relic.of("bizonho_graveto", Items.STICK, "Relíquia do Bizonho", 0xAA8650)
                .ench(Enchantments.KNOCKBACK, 50).shownAs("Repulsão 50"));

        // Calça de couro (sem tingir). Equipada: Herói da Vila V (renovado a cada 0,5s, 4s)
        add(Relic.of("fazendeiro", Items.LEATHER_LEGGINGS, "Relíquia do Fazendeiro", 0x137114)
                .ench(Enchantments.PROTECTION, 8)
                .wear(new Eff(StatusEffects.HERO_OF_THE_VILLAGE, 4, 80)));

        add(Relic.of("bizonho_machado", Items.DIAMOND_AXE, "Relíquia do Bizonho", 0xAA8650)
                .ench(Enchantments.KNOCKBACK, 150).shownAs("Repulsão 150"));

        add(Relic.of("minerador", Items.NETHERITE_PICKAXE, "Relíquia do Minerador", 0xF2EC38)
                .ench(Enchantments.FORTUNE, 3)
                .ench(Enchantments.EFFICIENCY, 10));

        add(Relic.of("cacador", Items.CROSSBOW, "Relíquia do Caçador", 0xD40C4B)
                .ench(Enchantments.PIERCING, 10)
                .ench(Enchantments.MULTISHOT, 3)      // "Rajada III"
                .ench(Enchantments.QUICK_CHARGE, 5));

        // Pé de coelho: encantado (encantamento escondido). No inventário: Sorte X
        add(Relic.of("sorte", Items.RABBIT_FOOT, "Relíquia da Sorte", 0x26E428)
                .ench(Enchantments.FORTUNE, 3).hide()
                .inventory(new Eff(StatusEffects.LUCK, 9, 80)));

        add(Relic.of("guerreiro", Items.NETHERITE_SWORD, "Relíquia do Guerreiro", 0xDA080E)
                .ench(Enchantments.SHARPNESS, 10)
                .ench(Enchantments.SMITE, 5)
                .ench(Enchantments.BANE_OF_ARTHROPODS, 5)
                .ench(Enchantments.SWEEPING_EDGE, 3)  // "Alcance III"
                .ench(Enchantments.KNOCKBACK, 3)
                .ench(Enchantments.LOOTING, 3));

        // Escudo: ao bloquear um golpe corpo a corpo, o atacante leva 13,5 de dano + repulsão
        add(Relic.of("defesa", Items.SHIELD, "Relíquia da Defesa", 0x7F7B7D)
                .ench(Enchantments.THORNS, 5));

        add(Relic.of("fim", Items.ELYTRA, "Relíquia do Fim", 0xF5F5B6)
                .ench(Enchantments.PROTECTION, 15).shownAs("Proteção XV"));

        // ===================== LINHA 2 =====================
        // Calça de couro violeta. Equipada: Mau Presságio V
        add(Relic.of("invasor", Items.LEATHER_LEGGINGS, "Relíquia do Invasor", 0x807B80)
                .dye(0x7C61AB)
                .ench(Enchantments.BINDING_CURSE, 1)
                .ench(Enchantments.VANISHING_CURSE, 1)
                .ench(Enchantments.PROTECTION, 8)
                .wear(new Eff(StatusEffects.BAD_OMEN, 4, 20)));

        // Totem controlado pelo mod: salva da morte e fica 10s em recarga
        add(Relic.of("imortalidade", Items.TOTEM_OF_UNDYING, "Relíquia da Imortalidade", 0x58C182));

        add(Relic.of("oceano", Items.TRIDENT, "Relíquia do Oceano", 0x4FE3E7)
                .ench(Enchantments.CHANNELING, 1)
                .ench(Enchantments.SHARPNESS, 5)
                .ench(Enchantments.IMPALING, 10)
                .ench(Enchantments.LOOTING, 3)
                .ench(Enchantments.LOYALTY, 3));

        // Botas: Passos Gelados II (já protege do magma) + anda sobre lava (ver RelicsMod)
        add(Relic.of("explorador", Items.DIAMOND_BOOTS, "Relíquia do Explorador", 0xC1AC29)
                .ench(Enchantments.FROST_WALKER, 2));

        // Biscoito: não dá pra comer; clique direito = efeito + recarga de 9 min
        add(Relic.of("espiao", Items.COOKIE, "Relíquia do Espião", 0xCE9661));

        // Carga de vento infinita: solta 2 cargas por clique
        add(Relic.of("vento", Items.WIND_CHARGE, "Relíquia do Deus do Vento", 0xE7E5EF));

        // Bússola de recuperação: rajada sônica
        add(Relic.of("warden", Items.RECOVERY_COMPASS, "Relíquia do Warden", 0x298085));

        // Clava: sem dano de queda na mão. Encantamentos da clava escondidos
        add(Relic.of("stomper", Items.MACE, "Relíquia do Stomper", 0x2B2A31)
                .ench(Enchantments.DENSITY, 5)
                .ench(Enchantments.BREACH, 4)
                .ench(Enchantments.WIND_BURST, 3).hide());

        // Ovo do dragão: teleporte aleatório (clique no ar ou no chão)
        add(Relic.of("dragao", Items.DRAGON_EGG, "Relíquia do Dragão", 0x6920E4));

        // ===================== LINHA 3 =====================
        // Botas de couro (sem tingir). Equipada: Invisibilidade XIII + esconde a armadura dos outros jogadores
        add(Relic.of("invisibilidade", Items.LEATHER_BOOTS, "Relíquia da Invisibilidade", 0xFFFFFF)
                .ench(Enchantments.PROTECTION, 10)
                .wear(new Eff(StatusEffects.INVISIBILITY, 12, 80)));

        // Capacete dourado. Equipado: Resistência ao Fogo V
        add(Relic.of("nether", Items.GOLDEN_HELMET, "Relíquia do Nether", 0xE7A325)
                .ench(Enchantments.PROTECTION, 8)
                .wear(new Eff(StatusEffects.FIRE_RESISTANCE, 4, 80)));
    }
}
