# IMDD Relics (Fabric 1.21.4)

Comando `/relics` abre o menu de relíquias.

## Compilar no GitHub
1. Crie um repositório e envie todo o conteúdo desta pasta (inclusive `.github`).
2. Abra a aba **Actions** > workflow **build** (roda sozinho a cada push, ou clique em *Run workflow*).
3. Quando ficar verde, abra a execução e baixe o artefato **imdd-relics** (o `.jar`).
4. Coloque o `.jar` na pasta `mods` junto com o **Fabric API 0.119.2+1.21.4**
   (precisa estar no servidor E no cliente, por causa do ícone/nome do efeito).
